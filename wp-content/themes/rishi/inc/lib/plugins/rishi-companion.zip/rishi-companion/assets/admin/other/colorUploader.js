jQuery(document).on( 'ready', function($){
    jQuery('.rc-uploader').wpColorPicker();
});