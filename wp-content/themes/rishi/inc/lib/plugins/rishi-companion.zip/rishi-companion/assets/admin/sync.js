import './sync/header'
import '../../framework/extensions/cookies-consent/js/sync'
import '../../framework/extensions/progress-bar/js/sync'
