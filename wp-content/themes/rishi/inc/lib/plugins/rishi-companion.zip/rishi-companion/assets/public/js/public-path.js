__webpack_public_path__ = rishi_companion_data.public_url;
