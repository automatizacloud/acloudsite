<?php

$config = [
	'name' => __('Cookies Consent', 'rishi-companion'),
	'description' => __('Enable this extension in order to comply with the GDPR regulations.', 'rishi-companion'),
	'slug' => 'cookie_consent_ext'
];
