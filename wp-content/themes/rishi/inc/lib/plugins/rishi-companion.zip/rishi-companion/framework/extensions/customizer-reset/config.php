<?php

$config = [
	'name' 			=> __( 'Customizer Reset', 'rishi-companion' ),
	'description' 	=> __( 'Enable this extension in order to reset to default settings.', 'rishi-companion' ),
	'slug' => 'customizer_reset_ext'
];
