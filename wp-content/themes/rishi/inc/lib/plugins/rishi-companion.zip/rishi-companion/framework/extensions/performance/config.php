<?php

$config = [
	'name' 			=> __( 'Performance', 'rishi-companion' ),
	'description' 	=> __( 'Enable this extension in order to enable performance related settings.', 'rishi-companion' ),
	'slug' 			=> 'performance_ext'
];
