<?php

$config = [
	'name' 			=> __( 'Reading Progress Bar', 'rishi-companion' ),
	'description' 	=> __( 'Enable this extension to add a reading progress bar on your website.', 'rishi-companion' ),
	'slug' 			=> 'progres_bar_ext'
];
