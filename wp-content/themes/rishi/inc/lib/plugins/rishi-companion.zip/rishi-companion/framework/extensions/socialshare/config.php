<?php

$config = [
	'name'        => __( 'Social Sharing', 'rishi-companion' ),
	'description' => __( 'Enable this extension to add social sharing option in single post.', 'rishi-companion' ),
	'slug'        => 'singlepost'
];
