<?php

$config = [
	'name' 			=> __( 'Transparent Header', 'rishi-companion' ),
	'description' 	=> __( 'Enable this extension in order to enable transparent header feature.', 'rishi-companion' ),
	'slug' 			=> 'header'
];
