<?php
/**
 * Rishi_Companion_WP_Upgrader_Skin class
 *
 * @package Rishi_Companion
 */

/**
 * Main Rishi_Companion_WP_Upgrader_Skin Cass.
 *
 * @package Rishi_Companion
 */
class Rishi_Companion_WP_Upgrader_Skin extends Plugin_Installer_Skin {
	
	public function header() {
	}

	public function footer() {
	}

	public function feedback( $string, ...$args) {
	}

	public function before() {
	}

	public function after() {
	}

	protected function decrement_update_count( $type ) {
	}

	public function bulk_header() {
	}

	public function bulk_footer() {
	}

	public function error( $errors ) {
	}
}
